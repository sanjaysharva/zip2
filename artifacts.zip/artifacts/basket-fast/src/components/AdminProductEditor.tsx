import { useMemo, useRef, useState, type CSSProperties } from 'react'
import { Check, Plus, X } from 'lucide-react'

type ProductDraft = {
  id: number
  name: string
  category: string
  price: number
  oldPrice?: number
  badge?: string
  colors: string[]
  sizes: string[]
  images: string[]
  image: string
  description: string
  tag: string
  rating: number
  reviews: number
}

type Props = {
  product: ProductDraft | null
  close: () => void
  save: (product: ProductDraft) => void | Promise<void>
}

const MAX_IMAGES = 6
const MAX_SOURCE_BYTES = 10 * 1024 * 1024
const MAX_COMPRESSED_BYTES = 300 * 1024
const PRODUCT_SIZES = ['XS', 'S', 'M', 'L', 'XL', 'XXL', '3XL', 'One size', 'A3']
const COLOR_PRESETS = [
  { name: 'Court black', value: '#141414' },
  { name: 'Fast orange', value: '#ff681f' },
  { name: 'Warm cream', value: '#e9e6dc' },
  { name: 'Clean white', value: '#faf8f1' },
  { name: 'Forest green', value: '#2f3c30' },
]

function colorName(value: string) {
  return COLOR_PRESETS.find((color) => color.value.toLowerCase() === value.toLowerCase())?.name ?? value
}

async function compressImage(file: File): Promise<string> {
  if (!['image/jpeg', 'image/png', 'image/webp'].includes(file.type)) {
    throw new Error(`${file.name}: choose a JPG, PNG, or WebP image.`)
  }
  if (file.size > MAX_SOURCE_BYTES) {
    throw new Error(`${file.name}: images must be 10 MB or smaller.`)
  }

  const objectUrl = URL.createObjectURL(file)
  try {
    const image = new Image()
    image.src = objectUrl
    await new Promise<void>((resolve, reject) => {
      image.onload = () => resolve()
      image.onerror = () => reject(new Error(`${file.name}: this image could not be opened.`))
    })

    const scale = Math.min(1, 1400 / Math.max(image.naturalWidth, image.naturalHeight))
    const canvas = document.createElement('canvas')
    canvas.width = Math.max(1, Math.round(image.naturalWidth * scale))
    canvas.height = Math.max(1, Math.round(image.naturalHeight * scale))
    const context = canvas.getContext('2d')
    if (!context) throw new Error('This browser could not prepare the image.')
    context.fillStyle = '#ffffff'
    context.fillRect(0, 0, canvas.width, canvas.height)
    context.drawImage(image, 0, 0, canvas.width, canvas.height)

    for (let quality = 0.86; quality >= 0.38; quality -= 0.08) {
      const dataUrl = canvas.toDataURL('image/jpeg', quality)
      const encoded = dataUrl.slice(dataUrl.indexOf(',') + 1)
      const approximateBytes = Math.floor(encoded.length * 0.75)
      if (approximateBytes <= MAX_COMPRESSED_BYTES) return dataUrl
    }
    throw new Error(`${file.name}: this image is too detailed to upload. Try a smaller image.`)
  } finally {
    URL.revokeObjectURL(objectUrl)
  }
}

export function AdminProductEditor({ product, close, save }: Props) {
  const fileInput = useRef<HTMLInputElement>(null)
  const [name, setName] = useState(product?.name || '')
  const [category, setCategory] = useState(product?.category || 'T-shirts')
  const [price, setPrice] = useState(`${product ? product.oldPrice ?? product.price : ''}`)
  const [offerPrice, setOfferPrice] = useState(`${product?.oldPrice ? product.price : ''}`)
  const [description, setDescription] = useState(product?.description || '')
  const [sizes, setSizes] = useState<string[]>(product?.sizes?.length ? product.sizes : ['S', 'M', 'L', 'XL'])
  const [customSize, setCustomSize] = useState('')
  const [colors, setColors] = useState<string[]>(product?.colors?.length ? product.colors : ['#141414', '#ff681f'])
  const [customColor, setCustomColor] = useState('#5d6d58')
  const [images, setImages] = useState<string[]>(product?.images?.length ? product.images : product?.image ? [product.image] : [])
  const [imageUrl, setImageUrl] = useState('')
  const [limited, setLimited] = useState(product?.badge === 'Limited')
  const [saving, setSaving] = useState(false)
  const [uploading, setUploading] = useState(false)
  const [error, setError] = useState('')

  const availableSizes = useMemo(
    () => [...PRODUCT_SIZES, ...sizes.filter((size) => !PRODUCT_SIZES.includes(size))],
    [sizes],
  )
  const availableColors = useMemo(
    () => [...COLOR_PRESETS.map((color) => color.value), ...colors].filter((color, index, all) => all.indexOf(color) === index),
    [colors],
  )

  const toggleSize = (size: string) => {
    setSizes((current) => current.includes(size) ? current.filter((item) => item !== size) : [...current, size])
  }

  const addCustomSize = () => {
    const value = customSize.trim()
    if (!value || sizes.some((size) => size.toLowerCase() === value.toLowerCase())) return
    setSizes((current) => [...current, value])
    setCustomSize('')
  }

  const toggleColor = (color: string) => {
    setColors((current) => current.includes(color) ? current.filter((item) => item !== color) : [...current, color])
  }

  const addImageUrl = () => {
    const value = imageUrl.trim()
    if (!value || images.includes(value) || images.length >= MAX_IMAGES) return
    setImages((current) => [...current, value])
    setImageUrl('')
    setError('')
  }

  const uploadImages = async (files: FileList | null) => {
    if (!files?.length) return
    const selectedFiles = Array.from(files)
    if (images.length + selectedFiles.length > MAX_IMAGES) {
      setError(`Choose up to ${MAX_IMAGES - images.length} more image${MAX_IMAGES - images.length === 1 ? '' : 's'}. The first image is the cover.`)
      if (fileInput.current) fileInput.current.value = ''
      return
    }
    setUploading(true)
    setError('')
    try {
      const compressed = await Promise.all(selectedFiles.map(compressImage))
      setImages((current) => [...current, ...compressed])
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : 'One or more images could not be uploaded.')
    } finally {
      setUploading(false)
      if (fileInput.current) fileInput.current.value = ''
    }
  }

  const submit = async () => {
    if (!name.trim() || !Number.isFinite(Number(price)) || Number(price) <= 0 || !images.length || images.length > MAX_IMAGES) return
    if (offerPrice && (!Number.isFinite(Number(offerPrice)) || Number(offerPrice) <= 0 || Number(offerPrice) >= Number(price))) {
      setError('Offer price must be greater than zero and lower than the regular price.')
      return
    }
    if (!sizes.length) {
      setError('Choose at least one size before publishing this product.')
      return
    }
    setSaving(true)
    setError('')
    try {
      await save({
        id: product?.id || 0,
        name: name.trim(),
        category: category.trim() || 'T-shirts',
        price: offerPrice ? Number(offerPrice) : Number(price),
        oldPrice: offerPrice ? Number(price) : undefined,
        colors,
        sizes,
        images,
        image: images[0],
        description: description.trim(),
        tag: description.trim() || 'Store piece',
        rating: product?.rating || 0,
        reviews: product?.reviews || 0,
        badge: limited ? 'Limited' : offerPrice ? 'Offer' : undefined,
      })
    } catch {
      setError('The product could not be saved. Check the details and try again.')
    } finally {
      setSaving(false)
    }
  }

  const makePrimary = (index: number) => setImages((current) => [current[index], ...current.filter((_, itemIndex) => itemIndex !== index)])
  const removeImage = (index: number) => setImages((current) => current.filter((_, itemIndex) => itemIndex !== index))

  return <div className="overlay modal-overlay">
    <div className="editor-modal admin-editor-modal">
      <button className="close-button" onClick={close} aria-label="Close product editor"><X size={20} /></button>
      <div className="editor-heading">
        <span className="section-kicker">Admin / Catalog</span>
        <h2>{product ? 'Edit piece.' : 'Add a new piece.'}</h2>
        <p>Set up the photos, available sizes, colors, and product details customers will see.</p>
      </div>
      <div className="editor-form">
        <div className="admin-editor-columns">
          <div className="admin-editor-fields">
            <label>Product name<input value={name} onChange={(event) => setName(event.target.value)} placeholder="e.g. Night Shift Tee" /></label>
            <div className="editor-row">
              <label>Category<input value={category} onChange={(event) => setCategory(event.target.value)} placeholder="T-shirts" /></label>
              <label>Regular price<input required min="1" type="number" value={price} onChange={(event) => setPrice(event.target.value)} placeholder="5499" /></label>
            </div>
            <div className="editor-row">
              <label>Offer price <small>Optional sale price</small><input min="0" type="number" value={offerPrice} onChange={(event) => setOfferPrice(event.target.value)} placeholder="No offer" /></label>
              <label className="editor-check"><input type="checkbox" checked={limited} onChange={(event) => setLimited(event.target.checked)} /> Limited piece</label>
            </div>
            <label>Description<textarea value={description} onChange={(event) => setDescription(event.target.value)} placeholder="Tell customers what makes this piece worth the rotation." rows={4} /></label>

            <fieldset className="admin-choice-field">
              <legend>Available sizes <small>Choose at least one</small></legend>
              <div className="admin-choice-grid">
                {availableSizes.map((size) => <label className="admin-choice" key={size}>
                  <input type="checkbox" checked={sizes.includes(size)} onChange={() => toggleSize(size)} />
                  <span>{size}</span>
                </label>)}
              </div>
              <div className="custom-size-row">
                <input value={customSize} onChange={(event) => setCustomSize(event.target.value)} onKeyDown={(event) => event.key === 'Enter' && (event.preventDefault(), addCustomSize())} placeholder="Add a custom size" aria-label="Custom size" />
                <button type="button" onClick={addCustomSize} disabled={!customSize.trim()}><Plus size={14} /> Add</button>
              </div>
              {!sizes.length && <small className="editor-validation">Select at least one size to publish.</small>}
            </fieldset>

            <fieldset className="admin-choice-field">
              <legend>Available colors <small>Select all that apply</small></legend>
              <div className="admin-color-options">
                {availableColors.map((color) => <button type="button" key={color} className={`admin-color-swatch ${colors.includes(color) ? 'selected' : ''}`} style={{ backgroundColor: color } as CSSProperties} onClick={() => toggleColor(color)} aria-label={`${colors.includes(color) ? 'Remove' : 'Add'} ${colorName(color)}`} aria-pressed={colors.includes(color)} title={colorName(color)} />)}
              </div>
              <div className="custom-color-row">
                <label className="custom-color-picker">Custom color<input type="color" value={customColor} onChange={(event) => setCustomColor(event.target.value)} /></label>
                <button type="button" onClick={() => toggleColor(customColor)}><Plus size={14} /> {colors.includes(customColor) ? 'Remove color' : 'Add color'}</button>
              </div>
            </fieldset>
          </div>

          <div className="admin-editor-media">
            <div className="media-heading">
              <div><strong>Product images</strong><small>Cover first, then up to 5 slideshow images.</small></div>
              <span>{images.length}/{MAX_IMAGES}</span>
            </div>
            <div className="editor-image-grid">
              {images.map((image, index) => <div className={`editor-image-card ${index === 0 ? 'is-primary' : ''}`} key={`${image.slice(0, 50)}-${index}`}>
                <img src={image} alt={`${name || 'Product'} ${index === 0 ? 'cover' : `view ${index + 1}`}`} />
                <span>{index === 0 ? 'Cover' : `View ${index + 1}`}</span>
                <div>
                  <button type="button" onClick={() => makePrimary(index)} disabled={index === 0}>Use cover</button>
                  <button type="button" onClick={() => removeImage(index)} aria-label={`Remove image ${index + 1}`}><X size={13} /></button>
                </div>
              </div>)}
            </div>
            <label className={`upload-images-button ${uploading || images.length >= MAX_IMAGES ? 'disabled' : ''}`}>
              <input ref={fileInput} type="file" accept="image/jpeg,image/png,image/webp" multiple disabled={uploading || images.length >= MAX_IMAGES} onChange={(event) => void uploadImages(event.currentTarget.files)} />
              <Plus size={16} /> {uploading ? 'Preparing images…' : 'Upload from device'}
            </label>
            <small className="image-upload-note">JPG, PNG, or WebP · up to 10 MB each · images are optimized for the store</small>
            <div className="add-image-row">
              <input value={imageUrl} onChange={(event) => setImageUrl(event.target.value)} onKeyDown={(event) => event.key === 'Enter' && (event.preventDefault(), addImageUrl())} placeholder="Or paste an image URL" aria-label="Image URL" />
              <button type="button" onClick={addImageUrl} disabled={!imageUrl.trim() || images.length >= MAX_IMAGES}><Plus size={15} /> Add</button>
            </div>
            {!images.length && <small className="editor-validation">Upload or add a cover image before publishing.</small>}
          </div>
        </div>

        <div className="editor-preview">
          {images[0] && <img src={images[0]} alt="" />}
          <div><strong>{name || 'Your new piece'}</strong><span>{description || 'Your product description will appear here.'}</span></div>
        </div>
        {error && <p className="admin-notice admin-notice-error" role="alert">{error}</p>}
        <button className="button button-orange full-button" onClick={() => void submit()} disabled={saving || uploading || !name.trim() || !price || !images.length || images.length > MAX_IMAGES || !sizes.length}>
          <Check size={16} /> {saving ? 'Saving piece…' : product ? 'Save changes' : 'Publish product'}
        </button>
      </div>
    </div>
  </div>
}